function openModule(moduleNumber) {
    const moduleNames = {
        1: "Introduction to Data Science",
        2: "Statistics & Probability",
        3: "Python for Data Science",
        4: "Machine Learning",
        5: "Data Visualization"
    };

    alert(
        "MODULE " + moduleNumber +
        "\n\n" + moduleNames[moduleNumber] +
        "\n\nModule content will be available here."
    );
}

const searchBox = document.getElementById("search");
const moduleCards = document.querySelectorAll(".module-card");

searchBox.addEventListener("input", function () {
    const searchValue = this.value.toLowerCase().trim();

    moduleCards.forEach(function (card) {
        const moduleName = card.getAttribute("data-name");

        card.style.display =
            moduleName.includes(searchValue) ? "block" : "none";
    });
});

const navLinks = document.querySelectorAll(".nav-link");

navLinks.forEach(function (link) {
    link.addEventListener("click", function () {
        navLinks.forEach(function (item) {
            item.classList.remove("active");
        });

        this.classList.add("active");
    });
});

const observer = new IntersectionObserver(
    function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.style.opacity = "1";
                entry.target.style.transform = "translateY(0)";
            }
        });
    },
    { threshold: 0.12 }
);

document.querySelectorAll(".module-card, .road-item").forEach(function (element) {
    element.style.opacity = "0";
    element.style.transform = "translateY(30px)";
    element.style.transition =
        "opacity .7s ease, transform .7s ease";

    observer.observe(element);
});

const profileImage = document.querySelector(".profile-picture img");
const fallback = document.getElementById("fallback");

profileImage.addEventListener("load", function () {
    fallback.style.display = "none";
});

profileImage.addEventListener("error", function () {
    profileImage.style.display = "none";
    fallback.style.display = "flex";
});

console.log("DataNova Data Science Portal Loaded Successfully 🚀");
